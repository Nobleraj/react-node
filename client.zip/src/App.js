import React from 'react';
import PostCreate from './components/postCreate';
import PostList from './components/postList';


const App = () =>{
    return <div className='container'>
        <h1>Create Post</h1>
        <PostCreate/>
        <PostList/>
    </div>
};

export default App;