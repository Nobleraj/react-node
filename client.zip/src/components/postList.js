import React, { useState,useEffect } from 'react';
import axios from 'axios';
import CommentsCraete from './commentsCreate';
import CommentList from './commentList';

const PostList = () => {
    const [posts,setPosts] = useState({});
    
    const api = async () => {
        await axios.get('http://localhost:4002/posts').then(res=>{
            setPosts(res.data);
        })
    };

    useEffect(()=>{
    api();
    },[]);

    const renderData = Object.values(posts).map(post=>{
        return (
            <div className='card' key={post.id} style={{width : '30%',marginBottom : '20px'}}>
                <div className='card-body'>
                    <h4>{post.title}</h4>
                    <CommentList comments = {post.comments}/>
                    <CommentsCraete postId = {post.id} />
                </div>
            </div>
        )
    });

    return(
         <div>
         <h1>Posts</h1>
         <div className='d-flex flex-row flex-wrap justify-content-between'>
         {renderData}
         </div>
        </div>
    )
};

export default PostList;