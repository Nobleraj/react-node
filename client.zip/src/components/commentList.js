import React from 'react';

const CommentList = ({comments}) => {

    const renderData = comments.map(post=>{
        let content = post.content;
        let status = post.status;
        if(status === 'pending'){
          content = 'Awaiting moderation';
        }
        if(status === 'rejected'){
            content = 'Content Rejected';
        }
        return (
            <li key={post.id}>
              {content}
            </li>
        )
    });

    return(
         <div>
         <span>Comments List</span>
         <ul className='d-flex flex-column flex-wrap justify-content-between'>
         {renderData}
         </ul>
        </div>
    )
};

export default CommentList;