import React, { useState } from 'react';
import axios from 'axios';

const CommentsCraete = (postId) => {
    const [content,setComments] = useState('');
    const id = postId.postId;
    const onSubmit = async (event) =>{
        event.preventDefault();
        if(!content)return;
        await axios.post(`http://localhost:4001/posts/${id}/comments`,{
            content
            }
        );
        setComments('');
    }

    return(
        <div>
            <form onSubmit={onSubmit}>
                <div className='form-group'>
                    <label>New comment</label>
                    <input className='form-control' value={content} onChange={(e)=>setComments(e.target.value)} />
                </div>
                <button style={{marginTop :'10px'}} className='btn btn-primary'>Submit</button>
            </form>
        </div>
    )
};

export default CommentsCraete;